1) This supplementary file is the simulation program for the Applied Energy submission "Core Temperature Modelling and Monitoring of Lithium-ion Battery in the Presence of Sensor Bias";
2) The simulation file can run well under the Environment of MATLAB R2018b
3) By executing the following commands,
     >>  UKF_temp()
     >>  EUKF_temp_bias()
   One can directly get the results shown in Fig. 8. 
   For other figures in Section 3, the codes should be accordingly modifed. 
4) MATLAB is a registered trademark is a trademark of The MathWorks, Inc. 