% close all  Extended UKF
clear,clc

%% Simulation based on EUKF
load TrainingData.mat    %  Training_data for identification. 
bias=10;   % temperature Sensor bias
t=Time_data;
x1=TC_data;   %TC
x2=TS_data+bias;  %Ts
I.data=I_data;
Tc0=x1(1);Ts0=x2(1); Tf=x2(1)-bias;

U=I.data.^2;
dt=t(2)-t(1);




%% filter parameter
n=3;      %number of state
q=0.01;    %std of process
r=0.1;    %std of measurement
Q=q^2*eye(n); % covariance of process
R=r^2;        % covariance of measurement
P =diag([100,100,100]);   % initial state covraiance  ����x3δ֪�������ˡ� 




%% model parameter
Coeff=[-0.00653066610442289,0.0702933926343024,-0.0659842856239285,0.00423915221509905,4.42903674145529e-07];
a1=Coeff(1);
a2=Coeff(2);
a3=Coeff(3);
a4=Coeff(4);
a5=Coeff(5);
f=@(x,u)[x(1)+dt*(a4*u-a1*(x(2)-x(1)));x(2)+dt*((-a3-a2)*(Tf-x(2))-a2*(x(2)-x(1))-a5*(x(2)^4-Tf^4));x(3)];  % nonlinear state equations
h=@(x)x(2)+x(3);                               % measurement equation
s=[Tc0;Ts0;0];                                % initial state
x=1*s; %initial state          % initial state with noise

N=length(U);                                     % total dynamic steps
xV = zeros(n,N);          %estmate        % allocate memory
sV = zeros(n,N);          %actual state
zV = zeros(1,N);
for k=1:N
    u=U(k);                                  % current input
    %   z = h(s) + r*randn;                     % model output measurments
    z =x2(k);                     % measurments
    sV(:,k)= s;                             % save actual state
    zV(k)  = z;                             % save measurment
    [x,P,K]=ukf_estimator(f,x,P,h,z,Q,R,u);    % UKF
    xV(:,k) = x;                            % save estimate
    %    s = f(s,u)+q*randn(2,1);                % update process
    s = f(s,u)  ;                % state update process
end


figure(2)
subplot(4,1,1)
plot(1:N,I.data,'b-','LineWidth',2)
ylabel('Electric Current (A)','Fontname','Times New Roman')
subplot(4,1,2)
plot(1:N, xV(1,:), 'r--','LineWidth',2)
hold on
h1=legend('Measurements','UKF estimation','EUKF estimation')
h1.FontName='Times New Roman';
ylabel('Core Temprature Tc (C^o)','Fontname','Times New Roman')
box on
subplot(4,1,3)
plot(1:N, xV(2,:), 'r--','LineWidth',2)
h1=legend('Biased Temperature Measurements','Actual Temperature','UKF estimation','EUKF estimation')
h1.FontName='Times New Roman';
ylabel('Surface Temprature Ts (C^o)','Fontname','Times New Roman')
% ylim([10 35])
box on
subplot(4,1,4)
plot(1:N,bias*ones(1,length(xV(3,:))),'b-',1:N,xV(3,:), 'r--','LineWidth',2)
h1=legend('Temperature Sensor Bias','Bias estimation')
h1.FontName='Times New Roman';
xlabel('t (s)','Fontname','Times New Roman')
ylabel('Temperature sensor bias (C^o)','Fontname','Times New Roman')
ylim([-2 12])



